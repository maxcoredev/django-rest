Rest
=====

Simple response serializer.

Detailed documentation is in the "docs" directory.

Quick start
-----------

1. Add "rest" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'rest',
    ]